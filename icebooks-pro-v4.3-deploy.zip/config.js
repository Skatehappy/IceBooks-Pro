/**
 * IceBooks Pro Configuration
 * 
 * INSTRUCTIONS:
 * 1. Go to your Supabase project dashboard
 * 2. Click Settings > API
 * 3. Copy your Project URL and paste below (replace the placeholder)
 * 4. Copy your "anon public" key and paste below (replace the placeholder)
 * 5. Save this file
 * 
 * IMPORTANT: Keep the quotes around the values!
 * IMPORTANT: The anon key should be ONE LONG LINE with no breaks!
 */

window.SUPABASE_URL = "https://your-project-id.supabase.co";
window.SUPABASE_ANON_KEY = "your-anon-key-here";
